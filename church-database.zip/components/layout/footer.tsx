export function Footer() {
  return (
    <footer className="bg-gradient-to-r from-blue-600 to-blue-700 border-t">
      <div className="flex items-center justify-center py-4 px-6">
        <p className="text-sm text-blue-100 italic">Touching Lives | Restoring Hope</p>
      </div>
    </footer>
  )
}
