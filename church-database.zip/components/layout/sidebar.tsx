"use client"

import Image from "next/image"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import {
  Home,
  Users,
  DollarSign,
  Calendar,
  BarChart3,
  Settings,
  LogOut,
  FileText,
  TrendingUp,
  User,
  ChevronDown,
  ChevronRight,
} from "lucide-react"
import { useAuth } from "@/contexts/auth-context"
import { useState } from "react"

export function Sidebar() {
  const { user, logout } = useAuth()
  const pathname = usePathname()
  const [expandedSections, setExpandedSections] = useState<string[]>(["membership"])

  const toggleSection = (section: string) => {
    setExpandedSections((prev) => (prev.includes(section) ? prev.filter((s) => s !== section) : [...prev, section]))
  }

  const isActive = (path: string) => pathname === path

  const handleLogout = () => {
    logout()
  }

  return (
    <div className="w-64 h-screen bg-gradient-to-b from-purple-600 via-purple-700 to-blue-800 text-white flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-white/20">
        <div className="flex items-center gap-3 mb-2">
          <Image src="/icc-logo-white.png" alt="ICC Logo" width={32} height={32} className="rounded-lg" />
          <div>
            <h1 className="text-sm font-bold">ICC LIVE</h1>
          </div>
        </div>

        {/* User Profile */}
        <div className="flex items-center gap-3 mt-4">
          <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
            <User className="h-6 w-6" />
          </div>
          <div>
            <p className="font-semibold text-sm">{user?.name?.toUpperCase() || "ADMIN"}</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        <Button
          variant="ghost"
          size="sm"
          asChild
          className={`w-full justify-start text-white hover:bg-white/20 ${isActive("/") ? "bg-white/20" : ""}`}
        >
          <Link href="/" className="flex items-center gap-3">
            <Home className="h-4 w-4" />
            Home
          </Link>
        </Button>

        {/* Membership Section */}
        <div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => toggleSection("membership")}
            className="w-full justify-between text-white hover:bg-white/20"
          >
            <div className="flex items-center gap-3">
              <Users className="h-4 w-4" />
              Membership
            </div>
            {expandedSections.includes("membership") ? (
              <ChevronDown className="h-4 w-4" />
            ) : (
              <ChevronRight className="h-4 w-4" />
            )}
          </Button>

          {expandedSections.includes("membership") && (
            <div className="ml-6 mt-1 space-y-1">
              <Button
                variant="ghost"
                size="sm"
                asChild
                className={`w-full justify-start text-white/80 hover:bg-white/20 text-xs ${
                  isActive("/members") ? "bg-white/20" : ""
                }`}
              >
                <Link href="/members">Membership Data</Link>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start text-white/80 hover:bg-white/20 text-xs"
              >
                Offices Held
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start text-white/80 hover:bg-white/20 text-xs"
              >
                Membership Reports
              </Button>
            </div>
          )}
        </div>

        {/* Financial Section */}
        <div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => toggleSection("financials")}
            className="w-full justify-between text-white hover:bg-white/20"
          >
            <div className="flex items-center gap-3">
              <DollarSign className="h-4 w-4" />
              Financials
            </div>
            {expandedSections.includes("financials") ? (
              <ChevronDown className="h-4 w-4" />
            ) : (
              <ChevronRight className="h-4 w-4" />
            )}
          </Button>

          {expandedSections.includes("financials") && (
            <div className="ml-6 mt-1 space-y-1">
              <Button
                variant="ghost"
                size="sm"
                asChild
                className={`w-full justify-start text-white/80 hover:bg-white/20 text-xs ${
                  isActive("/financial") ? "bg-white/20" : ""
                }`}
              >
                <Link href="/financial">Goodwill Offerings</Link>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                asChild
                className={`w-full justify-start text-white/80 hover:bg-white/20 text-xs ${
                  isActive("/expenditure") ? "bg-white/20" : ""
                }`}
              >
                <Link href="/expenditure">Expenditure</Link>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                asChild
                className={`w-full justify-start text-white/80 hover:bg-white/20 text-xs ${
                  isActive("/reports") ? "bg-white/20" : ""
                }`}
              >
                <Link href="/reports">Financial Reports</Link>
              </Button>
            </div>
          )}
        </div>

        <Button
          variant="ghost"
          size="sm"
          asChild
          className={`w-full justify-start text-white hover:bg-white/20 ${isActive("/birthdays") ? "bg-white/20" : ""}`}
        >
          <Link href="/birthdays" className="flex items-center gap-3">
            <Calendar className="h-4 w-4" />
            Birthdays
          </Link>
        </Button>

        <Button
          variant="ghost"
          size="sm"
          asChild
          className={`w-full justify-start text-white hover:bg-white/20 ${isActive("/analytics") ? "bg-white/20" : ""}`}
        >
          <Link href="/analytics" className="flex items-center gap-3">
            <BarChart3 className="h-4 w-4" />
            Analytics
          </Link>
        </Button>

        {/* Performance Management */}
        <div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => toggleSection("performance")}
            className="w-full justify-between text-white hover:bg-white/20"
          >
            <div className="flex items-center gap-3">
              <TrendingUp className="h-4 w-4" />
              Performance Mgt.
            </div>
            {expandedSections.includes("performance") ? (
              <ChevronDown className="h-4 w-4" />
            ) : (
              <ChevronRight className="h-4 w-4" />
            )}
          </Button>
        </div>

        {/* Target Reports */}
        <div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => toggleSection("reports")}
            className="w-full justify-between text-white hover:bg-white/20"
          >
            <div className="flex items-center gap-3">
              <FileText className="h-4 w-4" />
              Target Reports
            </div>
            {expandedSections.includes("reports") ? (
              <ChevronDown className="h-4 w-4" />
            ) : (
              <ChevronRight className="h-4 w-4" />
            )}
          </Button>
        </div>

        <Button
          variant="ghost"
          size="sm"
          asChild
          className={`w-full justify-start text-white hover:bg-white/20 ${isActive("/settings") ? "bg-white/20" : ""}`}
        >
          <Link href="/settings" className="flex items-center gap-3">
            <Settings className="h-4 w-4" />
            System Admin
          </Link>
        </Button>
      </nav>

      {/* Logout */}
      <div className="p-4 border-t border-white/20">
        <Button
          variant="ghost"
          size="sm"
          onClick={handleLogout}
          className="w-full justify-start text-white hover:bg-white/20"
        >
          <LogOut className="h-4 w-4 mr-3" />
          Logout
        </Button>
      </div>
    </div>
  )
}
