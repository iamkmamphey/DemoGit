"use client"

import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Users, DollarSign, Calendar, BarChart3, Settings, Menu, LogOut, User } from "lucide-react"
import { useAuth } from "@/contexts/auth-context"

export function Header() {
  const { user, logout } = useAuth()

  const handleLogout = () => {
    logout()
  }

  return (
    <header className="border-b bg-gradient-to-r from-blue-600 to-blue-700 shadow-sm">
      <div className="flex h-20 items-center justify-between px-6">
        {/* Logo and Title */}
        <div className="flex items-center gap-4">
          <Image src="/icc-logo-white.png" alt="ICC Logo" width={48} height={48} className="rounded-lg" />
          <div>
            <h1 className="text-xl font-semibold text-white">ICC</h1>
            <p className="text-[10px] text-blue-100">International Community Church</p>
          </div>
        </div>

        {/* Navigation */}
        <nav className="hidden md:flex items-center gap-1">
          <Button variant="ghost" size="sm" asChild className="text-white hover:bg-blue-500/20 hover:text-white">
            <Link href="/members" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Members
            </Link>
          </Button>
          <Button variant="ghost" size="sm" asChild className="text-white hover:bg-blue-500/20 hover:text-white">
            <Link href="/financial" className="flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Financial
            </Link>
          </Button>
          <Button variant="ghost" size="sm" asChild className="text-white hover:bg-blue-500/20 hover:text-white">
            <Link href="/birthdays" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Birthdays
            </Link>
          </Button>
          <Button variant="ghost" size="sm" asChild className="text-white hover:bg-blue-500/20 hover:text-white">
            <Link href="/analytics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Analytics
            </Link>
          </Button>
        </nav>

        {/* User Menu */}
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="flex items-center gap-2 text-white hover:bg-blue-500/20 hover:text-white"
              >
                <User className="h-4 w-4" />
                <span className="hidden sm:inline">{user?.name}</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <div className="px-2 py-1.5">
                <p className="text-sm font-medium">{user?.name}</p>
                <p className="text-xs text-gray-500">{user?.email}</p>
                <p className="text-xs text-gray-500 capitalize">Role: {user?.role}</p>
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link href="/settings" className="flex items-center gap-2">
                  <Settings className="h-4 w-4" />
                  Settings
                </Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout} className="flex items-center gap-2 text-red-600">
                <LogOut className="h-4 w-4" />
                Sign Out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Mobile Menu Button */}
          <Button variant="ghost" size="sm" className="md:hidden text-white hover:bg-blue-500/20 hover:text-white">
            <Menu className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </header>
  )
}
