"use client"

import type React from "react"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"

interface ProtectedRouteProps {
  children: React.ReactNode
  requiredPermission?: string
  fallbackPath?: string
}

export function ProtectedRoute({ children, requiredPermission, fallbackPath = "/login" }: ProtectedRouteProps) {
  const { isAuthenticated, isLoading, user } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!isLoading) {
      if (!isAuthenticated) {
        router.push(fallbackPath)
        return
      }

      // Check specific permissions if required
      if (requiredPermission && user) {
        const hasPermission = checkUserPermission(user, requiredPermission)
        if (!hasPermission) {
          router.push("/unauthorized")
          return
        }
      }
    }
  }, [isAuthenticated, isLoading, user, requiredPermission, router, fallbackPath])

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return null // Will redirect to login
  }

  return <>{children}</>
}

function checkUserPermission(user: any, permission: string): boolean {
  const permissions: Record<string, string[]> = {
    admin: ["read", "write", "delete", "manage_users", "view_analytics", "manage_financials"],
    staff: ["read", "write", "view_analytics", "manage_financials"],
    volunteer: ["read"],
  }

  return permissions[user.role]?.includes(permission) || false
}

export default ProtectedRoute
