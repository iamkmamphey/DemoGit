"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Home, ArrowUp } from "lucide-react"
import { useRouter } from "next/navigation"

export function NavigationButtons() {
  const [showBackToTop, setShowBackToTop] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 300)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const goHome = () => {
    router.push("/")
  }

  return (
    <div className="fixed bottom-6 right-6 flex flex-col gap-3 z-50">
      {/* Return to Home Button */}
      <Button
        onClick={goHome}
        className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg hover:shadow-xl transition-all duration-200 rounded-full p-3"
        size="icon"
        title="Return to Home"
      >
        <Home className="h-5 w-5" />
      </Button>

      {/* Back to Top Button - Only show when scrolled */}
      {showBackToTop && (
        <Button
          onClick={scrollToTop}
          className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white shadow-lg hover:shadow-xl transition-all duration-200 rounded-full p-3 animate-in slide-in-from-bottom-2"
          size="icon"
          title="Back to Top"
        >
          <ArrowUp className="h-5 w-5" />
        </Button>
      )}
    </div>
  )
}
