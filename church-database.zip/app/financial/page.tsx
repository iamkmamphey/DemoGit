"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/auth-context"
import { AuthService } from "@/lib/auth"
import { Header } from "@/components/layout/header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Search, DollarSign, Calendar, User, Edit, Trash2, TrendingUp } from "lucide-react"
import { financialDb, memberDb } from "@/lib/database"
import type { FinancialRecord, Member } from "@/lib/types"
import Link from "next/link"
import { NavigationButtons } from "@/components/ui/navigation-buttons"

export default function FinancialPage() {
  const { user } = useAuth()
  const [records, setRecords] = useState<FinancialRecord[]>([])
  const [members, setMembers] = useState<Member[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [typeFilter, setTypeFilter] = useState<string>("all")
  const [paymentMethodFilter, setPaymentMethodFilter] = useState<string>("all")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!AuthService.canAccessFinancials(user)) {
      return
    }
    loadData()
  }, [user])

  const loadData = () => {
    setLoading(true)
    const allRecords = financialDb.getAll()
    const allMembers = memberDb.getAll()
    setRecords(allRecords)
    setMembers(allMembers)
    setLoading(false)
  }

  const getMemberName = (memberId: string) => {
    const member = members.find((m) => m.id === memberId)
    return member ? `${member.firstName} ${member.lastName}` : "Unknown Member"
  }

  const filteredRecords = records.filter((record) => {
    const memberName = getMemberName(record.memberId).toLowerCase()
    const matchesSearch =
      memberName.includes(searchTerm.toLowerCase()) ||
      record.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.amount.toString().includes(searchTerm)

    const matchesType = typeFilter === "all" || record.type === typeFilter
    const matchesPaymentMethod = paymentMethodFilter === "all" || record.paymentMethod === paymentMethodFilter

    return matchesSearch && matchesType && matchesPaymentMethod
  })

  const handleDeleteRecord = (id: string) => {
    if (!AuthService.canDeleteFinancials(user)) {
      alert("You don't have permission to delete financial records.")
      return
    }

    if (confirm("Are you sure you want to delete this financial record?")) {
      financialDb.delete(id)
      loadData()
    }
  }

  const getTypeColor = (type: FinancialRecord["type"]) => {
    switch (type) {
      case "tithe":
        return "bg-green-100 text-green-800"
      case "goodwill":
        return "bg-blue-100 text-blue-800"
      case "donation":
        return "bg-purple-100 text-purple-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString()
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(amount)
  }

  const totalAmount = filteredRecords.reduce((sum, record) => sum + record.amount, 0)
  const totalTithes = filteredRecords.filter((r) => r.type === "tithe").reduce((sum, record) => sum + record.amount, 0)
  const totalGoodwill = filteredRecords
    .filter((r) => r.type === "goodwill")
    .reduce((sum, record) => sum + record.amount, 0)
  const totalDonations = filteredRecords
    .filter((r) => r.type === "donation")
    .reduce((sum, record) => sum + record.amount, 0)

  if (!AuthService.canAccessFinancials(user)) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="p-6">
          <div className="max-w-7xl mx-auto">
            <Card>
              <CardContent className="text-center py-12">
                <h2 className="text-xl font-semibold text-gray-900 mb-2">Access Denied</h2>
                <p className="text-gray-600">You don't have permission to access financial records.</p>
              </CardContent>
            </Card>
          </div>
        </div>
        <NavigationButtons />
      </div>
    )
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="p-6">
          <div className="max-w-7xl mx-auto">
            <div className="text-center py-12">Loading financial records...</div>
          </div>
        </div>
        <NavigationButtons />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <main className="p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Financial Records</h1>
              <p className="text-gray-600">Track tithes, goodwill offerings, and donations from church members</p>
            </div>
            {AuthService.canModifyFinancials(user) && (
              <Button asChild>
                <Link href="/financial/new" className="flex items-center gap-2">
                  <Plus className="h-4 w-4" />
                  Add Record
                </Link>
              </Button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Amount</CardTitle>
                <TrendingUp className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(totalAmount)}</div>
                <p className="text-xs text-muted-foreground">{filteredRecords.length} records</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Tithes</CardTitle>
                <DollarSign className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(totalTithes)}</div>
                <p className="text-xs text-muted-foreground">
                  {filteredRecords.filter((r) => r.type === "tithe").length} records
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Goodwill</CardTitle>
                <DollarSign className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(totalGoodwill)}</div>
                <p className="text-xs text-muted-foreground">
                  {filteredRecords.filter((r) => r.type === "goodwill").length} records
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Donations</CardTitle>
                <DollarSign className="h-4 w-4 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(totalDonations)}</div>
                <p className="text-xs text-muted-foreground">
                  {filteredRecords.filter((r) => r.type === "donation").length} records
                </p>
              </CardContent>
            </Card>
          </div>

          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="flex flex-col lg:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      placeholder="Search by member name, amount, or description..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <Select value={typeFilter} onValueChange={setTypeFilter}>
                  <SelectTrigger className="w-full lg:w-48">
                    <SelectValue placeholder="Filter by type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="tithe">Tithe</SelectItem>
                    <SelectItem value="goodwill">Goodwill</SelectItem>
                    <SelectItem value="donation">Donation</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={paymentMethodFilter} onValueChange={setPaymentMethodFilter}>
                  <SelectTrigger className="w-full lg:w-48">
                    <SelectValue placeholder="Payment method" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Methods</SelectItem>
                    <SelectItem value="cash">Cash</SelectItem>
                    <SelectItem value="check">Check</SelectItem>
                    <SelectItem value="card">Card</SelectItem>
                    <SelectItem value="online">Online</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {filteredRecords.length === 0 ? (
            <Card>
              <CardContent className="text-center py-12">
                <p className="text-gray-500 mb-4">
                  {searchTerm || typeFilter !== "all" || paymentMethodFilter !== "all"
                    ? "No financial records found matching your criteria."
                    : "No financial records added yet."}
                </p>
                {AuthService.canModifyFinancials(user) && (
                  <Button asChild>
                    <Link href="/financial/new">Add Your First Record</Link>
                  </Button>
                )}
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="border-b bg-gray-50">
                      <tr>
                        <th className="text-left p-4 font-medium">Member</th>
                        <th className="text-left p-4 font-medium">Type</th>
                        <th className="text-left p-4 font-medium">Amount</th>
                        <th className="text-left p-4 font-medium">Date</th>
                        <th className="text-left p-4 font-medium">Payment Method</th>
                        <th className="text-left p-4 font-medium">Description</th>
                        {AuthService.canModifyFinancials(user) && (
                          <th className="text-right p-4 font-medium">Actions</th>
                        )}
                      </tr>
                    </thead>
                    <tbody>
                      {filteredRecords
                        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                        .map((record) => (
                          <tr key={record.id} className="border-b hover:bg-gray-50">
                            <td className="p-4">
                              <div className="flex items-center gap-2">
                                <User className="h-4 w-4 text-gray-400" />
                                <span className="font-medium">{getMemberName(record.memberId)}</span>
                              </div>
                            </td>
                            <td className="p-4">
                              <Badge className={getTypeColor(record.type)}>{record.type}</Badge>
                            </td>
                            <td className="p-4">
                              <span className="font-semibold text-green-600">{formatCurrency(record.amount)}</span>
                            </td>
                            <td className="p-4">
                              <div className="flex items-center gap-2">
                                <Calendar className="h-4 w-4 text-gray-400" />
                                <span>{formatDate(record.date)}</span>
                              </div>
                            </td>
                            <td className="p-4">
                              <span className="capitalize">{record.paymentMethod}</span>
                            </td>
                            <td className="p-4">
                              <span className="text-gray-600 truncate max-w-xs block">{record.description || "—"}</span>
                            </td>
                            {AuthService.canModifyFinancials(user) && (
                              <td className="p-4">
                                <div className="flex justify-end gap-1">
                                  <Button variant="ghost" size="sm" asChild>
                                    <Link href={`/financial/${record.id}/edit`}>
                                      <Edit className="h-4 w-4" />
                                    </Link>
                                  </Button>
                                  {AuthService.canDeleteFinancials(user) && (
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => handleDeleteRecord(record.id)}
                                      className="text-red-600 hover:text-red-700"
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  )}
                                </div>
                              </td>
                            )}
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
      <NavigationButtons />
    </div>
  )
}
