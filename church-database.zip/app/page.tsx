"use client"

import { useEffect } from "react"
import { Sidebar } from "@/components/layout/sidebar"
import { Footer } from "@/components/layout/footer"
import { ProtectedRoute } from "@/components/auth/protected-route"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Users, Search, Eye, X, UserCheck, Baby, User } from "lucide-react"
import { initializeSampleData, memberDb } from "@/lib/database"

function DashboardContent() {
  useEffect(() => {
    initializeSampleData()
  }, [])

  const allMembers = memberDb.getAll()
  const totalMembers = allMembers.length

  const getAge = (dateOfBirth: string) => {
    const today = new Date()
    const birthDate = new Date(dateOfBirth)
    let age = today.getFullYear() - birthDate.getFullYear()
    const monthDiff = today.getMonth() - birthDate.getMonth()
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--
    }
    return age
  }

  const membersByAge = allMembers.reduce(
    (acc, member) => {
      const age = getAge(member.dateOfBirth)
      if (age >= 26) acc.adults++
      else if (age >= 13) acc.youth++
      else acc.children++
      return acc
    },
    { adults: 0, youth: 0, children: 0 },
  )

  const membersByGender = allMembers.reduce(
    (acc, member) => {
      if (member.gender === "female") acc.female++
      else acc.male++
      return acc
    },
    { female: 0, male: 0 },
  )

  const thisMonth = new Date().getMonth()
  const thisYear = new Date().getFullYear()
  const newThisMonth = allMembers.filter((member) => {
    const joinDate = new Date(member.joinDate || member.dateOfBirth)
    return joinDate.getMonth() === thisMonth && joinDate.getFullYear() === thisYear
  }).length

  return (
    <div className="flex min-h-screen bg-gradient-to-br from-purple-600 via-purple-700 to-blue-800">
      <Sidebar />

      <div className="flex-1 flex flex-col">
        <main className="flex-1 p-6 overflow-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="bg-pink-500 text-white px-4 py-2 rounded-lg">
              <h1 className="text-lg font-semibold">Members List</h1>
            </div>

            <div className="flex items-center gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/60 h-4 w-4" />
                <Input
                  placeholder="Search"
                  className="pl-10 bg-white/20 border-white/30 text-white placeholder:text-white/60 w-80"
                />
              </div>
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                <User className="h-5 w-5 text-white" />
              </div>
            </div>
          </div>

          {/* Search and Filters */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Input placeholder="General Search" className="bg-white/90 border-white/30" />
            <Select>
              <SelectTrigger className="bg-white/90 border-white/30">
                <SelectValue placeholder="Old/New Membership Numbers" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="old">Old Members</SelectItem>
                <SelectItem value="new">New Members</SelectItem>
              </SelectContent>
            </Select>
            <Select>
              <SelectTrigger className="bg-white/90 border-white/30">
                <SelectValue placeholder="All" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
            <div className="flex gap-2">
              <Button className="bg-blue-600 hover:bg-blue-700 text-white flex-1">
                <Eye className="h-4 w-4 mr-2" />
                View Members
              </Button>
              <Button variant="outline" className="bg-white/90 text-gray-700 hover:bg-white">
                <X className="h-4 w-4 mr-2" />
                Clear Filter
              </Button>
            </div>
          </div>

          {/* Statistics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
            {/* Total Active Members */}
            <Card className="bg-white/95 backdrop-blur">
              <CardHeader className="text-center pb-2">
                <CardTitle className="text-sm text-gray-600">Number of Active Members</CardTitle>
                <div className="text-4xl font-bold text-gray-800">{totalMembers}</div>
                <p className="text-xs text-gray-500">100% of the church</p>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="flex items-center justify-center gap-4 text-sm">
                  <Users className="h-8 w-8 text-gray-400" />
                </div>
                <div className="flex justify-between text-xs mt-2">
                  <div className="text-center">
                    <div className="font-bold">{membersByGender.female}</div>
                    <div>FEMALE</div>
                  </div>
                  <div className="text-center">
                    <div className="font-bold">{membersByGender.male}</div>
                    <div>MALE</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Adults */}
            <Card className="bg-white/95 backdrop-blur">
              <CardHeader className="text-center pb-2">
                <CardTitle className="text-sm text-gray-600">Adults (Age 26 and Above)</CardTitle>
                <div className="text-4xl font-bold text-gray-800">{membersByAge.adults}</div>
                <p className="text-xs text-gray-500">
                  {((membersByAge.adults / totalMembers) * 100).toFixed(2)}% of the church
                </p>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="flex items-center justify-center gap-4 text-sm">
                  <UserCheck className="h-8 w-8 text-gray-400" />
                </div>
                <div className="flex justify-between text-xs mt-2">
                  <div className="text-center">
                    <div className="font-bold">{Math.floor(membersByAge.adults * 0.6)}</div>
                    <div>FEMALE</div>
                  </div>
                  <div className="text-center">
                    <div className="font-bold">{Math.ceil(membersByAge.adults * 0.4)}</div>
                    <div>MALE</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Youth */}
            <Card className="bg-white/95 backdrop-blur">
              <CardHeader className="text-center pb-2">
                <CardTitle className="text-sm text-gray-600">Youth (Age 13 to 25)</CardTitle>
                <div className="text-4xl font-bold text-gray-800">{membersByAge.youth}</div>
                <p className="text-xs text-gray-500">
                  {((membersByAge.youth / totalMembers) * 100).toFixed(2)}% of the church
                </p>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between">
                    <span>Junior Youth</span>
                    <span className="font-bold">6</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Senior Youth</span>
                    <span className="font-bold">17</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Young Adults</span>
                    <span className="font-bold">22</span>
                  </div>
                </div>
                <div className="flex justify-between text-xs mt-2">
                  <div className="text-center">
                    <div className="font-bold">{Math.floor(membersByAge.youth * 0.55)}</div>
                    <div>FEMALE</div>
                  </div>
                  <div className="text-center">
                    <div className="font-bold">{Math.ceil(membersByAge.youth * 0.45)}</div>
                    <div>MALE</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Children */}
            <Card className="bg-white/95 backdrop-blur">
              <CardHeader className="text-center pb-2">
                <CardTitle className="text-sm text-gray-600">Children (Below Age 13)</CardTitle>
                <div className="text-4xl font-bold text-gray-800">{membersByAge.children}</div>
                <p className="text-xs text-gray-500">
                  {((membersByAge.children / totalMembers) * 100).toFixed(2)}% of the church
                </p>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="flex items-center justify-center gap-4 text-sm">
                  <Baby className="h-8 w-8 text-gray-400" />
                </div>
                <div className="flex justify-between text-xs mt-2">
                  <div className="text-center">
                    <div className="font-bold">{Math.floor(membersByAge.children * 0.5)}</div>
                    <div>FEMALE</div>
                  </div>
                  <div className="text-center">
                    <div className="font-bold">{Math.ceil(membersByAge.children * 0.5)}</div>
                    <div>MALE</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* New Registrants and Growth Chart */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* New Registrants */}
            <Card className="bg-white/95 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-2xl font-bold">{newThisMonth}</CardTitle>
                <CardDescription>New registrants this month</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4 text-center text-sm">
                  <div>
                    <div className="font-bold">1</div>
                    <div>CHILDREN</div>
                  </div>
                  <div>
                    <div className="font-bold">0</div>
                    <div>YOUTH</div>
                  </div>
                  <div>
                    <div className="font-bold">3</div>
                    <div>ADULTS</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Growth Chart Placeholder */}
            <Card className="lg:col-span-2 bg-white/95 backdrop-blur">
              <CardHeader>
                <CardTitle>Membership Growth</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-32 bg-gradient-to-r from-purple-100 to-blue-100 rounded-lg flex items-center justify-center">
                  <p className="text-gray-600">Growth Chart - Coming Soon</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>

        <Footer />
      </div>
    </div>
  )
}

export default function HomePage() {
  return (
    <ProtectedRoute>
      <DashboardContent />
    </ProtectedRoute>
  )
}
