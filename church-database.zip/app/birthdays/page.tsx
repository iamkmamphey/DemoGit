"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/layout/header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Calendar, Gift, Mail, User, Send, Clock, Search } from "lucide-react"
import { memberDb, birthdayDb } from "@/lib/database"
import type { Member, BirthdayNote } from "@/lib/types"

interface BirthdayMember extends Member {
  daysUntilBirthday: number
  age: number
  birthdayThisYear: Date
}

export default function BirthdaysPage() {
  const [members, setMembers] = useState<Member[]>([])
  const [birthdayMembers, setBirthdayMembers] = useState<BirthdayMember[]>([])
  const [birthdayNotes, setBirthdayNotes] = useState<BirthdayNote[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedMember, setSelectedMember] = useState<BirthdayMember | null>(null)
  const [noteMessage, setNoteMessage] = useState("")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = () => {
    setLoading(true)
    const allMembers = memberDb.getAll().filter((member) => member.status === "active")
    const allNotes = birthdayDb.getAll()

    setMembers(allMembers)
    setBirthdayNotes(allNotes)

    // Calculate birthday information
    const today = new Date()
    const currentYear = today.getFullYear()

    const membersWithBirthdays = allMembers.map((member) => {
      const birthDate = new Date(member.dateOfBirth)
      const birthdayThisYear = new Date(currentYear, birthDate.getMonth(), birthDate.getDate())

      // If birthday has passed this year, calculate for next year
      if (birthdayThisYear < today) {
        birthdayThisYear.setFullYear(currentYear + 1)
      }

      const daysUntilBirthday = Math.ceil((birthdayThisYear.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
      const age = currentYear - birthDate.getFullYear()

      return {
        ...member,
        daysUntilBirthday,
        age,
        birthdayThisYear,
      }
    })

    // Sort by days until birthday
    membersWithBirthdays.sort((a, b) => a.daysUntilBirthday - b.daysUntilBirthday)
    setBirthdayMembers(membersWithBirthdays)
    setLoading(false)
  }

  const filteredMembers = birthdayMembers.filter((member) => {
    const fullName = `${member.firstName} ${member.lastName}`.toLowerCase()
    return fullName.includes(searchTerm.toLowerCase())
  })

  const upcomingBirthdays = filteredMembers.filter((member) => member.daysUntilBirthday <= 30)
  const todaysBirthdays = filteredMembers.filter((member) => member.daysUntilBirthday === 0)
  const thisWeeksBirthdays = filteredMembers.filter(
    (member) => member.daysUntilBirthday <= 7 && member.daysUntilBirthday > 0,
  )

  const handleSendNote = () => {
    if (!selectedMember || !noteMessage.trim()) return

    const note: Omit<BirthdayNote, "id"> = {
      memberId: selectedMember.id,
      year: new Date().getFullYear(),
      message: noteMessage.trim(),
      sentDate: new Date().toISOString(),
      createdBy: "Church Admin", // In a real app, this would be the logged-in user
    }

    birthdayDb.create(note)
    setNoteMessage("")
    setSelectedMember(null)
    loadData()
    alert(`Birthday note sent to ${selectedMember.firstName} ${selectedMember.lastName}!`)
  }

  const getMemberNotes = (memberId: string) => {
    return birthdayNotes.filter((note) => note.memberId === memberId)
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      month: "long",
      day: "numeric",
    })
  }

  const formatDateWithYear = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "long",
      day: "numeric",
      year: "numeric",
    })
  }

  const getBirthdayBadgeColor = (days: number) => {
    if (days === 0) return "bg-red-100 text-red-800"
    if (days <= 7) return "bg-orange-100 text-orange-800"
    if (days <= 30) return "bg-blue-100 text-blue-800"
    return "bg-gray-100 text-gray-800"
  }

  const getBirthdayText = (days: number) => {
    if (days === 0) return "Today!"
    if (days === 1) return "Tomorrow"
    if (days <= 7) return `${days} days`
    return `${days} days`
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="p-6">
          <div className="max-w-7xl mx-auto">
            <div className="text-center py-12">Loading birthday information...</div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <main className="p-6">
        <div className="max-w-7xl mx-auto">
          {/* Header Section */}
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Birthday Notifications</h1>
            <p className="text-gray-600">Send personalized birthday messages to church members</p>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card className="border-red-200 bg-red-50">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Today's Birthdays</CardTitle>
                <Gift className="h-4 w-4 text-red-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-600">{todaysBirthdays.length}</div>
                <p className="text-xs text-red-700">Celebrate today!</p>
              </CardContent>
            </Card>

            <Card className="border-orange-200 bg-orange-50">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">This Week</CardTitle>
                <Calendar className="h-4 w-4 text-orange-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-orange-600">{thisWeeksBirthdays.length}</div>
                <p className="text-xs text-orange-700">Next 7 days</p>
              </CardContent>
            </Card>

            <Card className="border-blue-200 bg-blue-50">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Next 30 Days</CardTitle>
                <Clock className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">{upcomingBirthdays.length}</div>
                <p className="text-xs text-blue-700">Upcoming birthdays</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Upcoming Birthdays List */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    Upcoming Birthdays
                  </CardTitle>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      placeholder="Search members..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </CardHeader>
                <CardContent className="space-y-3 max-h-96 overflow-y-auto">
                  {upcomingBirthdays.length === 0 ? (
                    <p className="text-gray-500 text-center py-4">No upcoming birthdays in the next 30 days.</p>
                  ) : (
                    upcomingBirthdays.map((member) => (
                      <div
                        key={member.id}
                        className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 cursor-pointer"
                        onClick={() => setSelectedMember(member)}
                      >
                        <div className="flex items-center gap-3">
                          <User className="h-8 w-8 text-gray-400" />
                          <div>
                            <div className="font-medium">
                              {member.firstName} {member.lastName}
                            </div>
                            <div className="text-sm text-gray-500">
                              {formatDate(member.birthdayThisYear)} • Turning {member.age + 1}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className={getBirthdayBadgeColor(member.daysUntilBirthday)}>
                            {getBirthdayText(member.daysUntilBirthday)}
                          </Badge>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              setSelectedMember(member)
                            }}
                          >
                            <Mail className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Send Birthday Note */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Send className="h-5 w-5" />
                    Send Birthday Note
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {selectedMember ? (
                    <>
                      <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                        <div className="font-medium">
                          {selectedMember.firstName} {selectedMember.lastName}
                        </div>
                        <div className="text-sm text-gray-600">
                          Birthday: {formatDate(selectedMember.birthdayThisYear)} • Turning {selectedMember.age + 1}
                        </div>
                        <div className="text-sm text-blue-600">{getBirthdayText(selectedMember.daysUntilBirthday)}</div>
                      </div>

                      <div>
                        <Label htmlFor="noteMessage">Birthday Message</Label>
                        <Textarea
                          id="noteMessage"
                          value={noteMessage}
                          onChange={(e) => setNoteMessage(e.target.value)}
                          placeholder={`Dear ${selectedMember.firstName},\n\nHappy Birthday! We hope you have a wonderful day filled with joy and blessings.\n\nWith love,\nICC Family`}
                          rows={6}
                          className="mt-1"
                        />
                      </div>

                      <div className="flex gap-2">
                        <Button onClick={handleSendNote} disabled={!noteMessage.trim()}>
                          <Send className="h-4 w-4 mr-2" />
                          Send Note
                        </Button>
                        <Button variant="outline" onClick={() => setSelectedMember(null)}>
                          Cancel
                        </Button>
                      </div>

                      {/* Previous Notes */}
                      {getMemberNotes(selectedMember.id).length > 0 && (
                        <div className="mt-4 pt-4 border-t">
                          <h4 className="font-medium mb-2">Previous Birthday Notes</h4>
                          <div className="space-y-2 max-h-32 overflow-y-auto">
                            {getMemberNotes(selectedMember.id)
                              .sort((a, b) => new Date(b.sentDate).getTime() - new Date(a.sentDate).getTime())
                              .map((note) => (
                                <div key={note.id} className="text-sm p-2 bg-gray-50 rounded">
                                  <div className="font-medium">{note.year}</div>
                                  <div className="text-gray-600 truncate">{note.message}</div>
                                  <div className="text-xs text-gray-500">Sent: {formatDateWithYear(note.sentDate)}</div>
                                </div>
                              ))}
                          </div>
                        </div>
                      )}
                    </>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <Mail className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                      <p>Select a member from the list to send a birthday note</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Recent Birthday Notes */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Recent Birthday Notes</CardTitle>
            </CardHeader>
            <CardContent>
              {birthdayNotes.length === 0 ? (
                <p className="text-gray-500 text-center py-4">No birthday notes sent yet.</p>
              ) : (
                <div className="space-y-3">
                  {birthdayNotes
                    .sort((a, b) => new Date(b.sentDate).getTime() - new Date(a.sentDate).getTime())
                    .slice(0, 5)
                    .map((note) => {
                      const member = members.find((m) => m.id === note.memberId)
                      return (
                        <div key={note.id} className="flex items-start gap-3 p-3 border rounded-lg">
                          <User className="h-8 w-8 text-gray-400 mt-1" />
                          <div className="flex-1">
                            <div className="font-medium">
                              {member ? `${member.firstName} ${member.lastName}` : "Unknown Member"}
                            </div>
                            <div className="text-sm text-gray-600 mt-1">{note.message}</div>
                            <div className="text-xs text-gray-500 mt-2">
                              Sent: {formatDateWithYear(note.sentDate)} • {note.year} Birthday
                            </div>
                          </div>
                        </div>
                      )
                    })}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
