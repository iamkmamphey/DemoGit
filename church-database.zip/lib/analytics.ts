// Analytics utilities for ICC Church Management System
import { memberDb, financialDb, birthdayDb } from "./database"

export interface MembershipGrowthData {
  month: string
  totalMembers: number
  newMembers: number
  activeMembers: number
}

export interface FinancialAnalytics {
  month: string
  tithes: number
  goodwill: number
  donations: number
  total: number
}

export interface MemberContribution {
  memberId: string
  memberName: string
  totalContributions: number
  contributionCount: number
  averageContribution: number
  lastContribution: string
}

export interface DashboardMetrics {
  totalMembers: number
  activeMembers: number
  totalFinancialRecords: number
  totalContributions: number
  averageMonthlyGiving: number
  birthdayNotesThisYear: number
  membershipGrowthRate: number
  topContributors: MemberContribution[]
}

export function calculateMembershipGrowth(): MembershipGrowthData[] {
  const members = memberDb.getAll()
  const monthlyData: { [key: string]: MembershipGrowthData } = {}

  // Initialize last 12 months
  const now = new Date()
  for (let i = 11; i >= 0; i--) {
    const date = new Date(now.getFullYear(), now.getMonth() - i, 1)
    const monthKey = date.toISOString().slice(0, 7) // YYYY-MM format
    const monthName = date.toLocaleDateString("en-US", { month: "short", year: "numeric" })

    monthlyData[monthKey] = {
      month: monthName,
      totalMembers: 0,
      newMembers: 0,
      activeMembers: 0,
    }
  }

  // Calculate membership data for each month
  Object.keys(monthlyData).forEach((monthKey) => {
    const monthEnd = new Date(monthKey + "-01")
    monthEnd.setMonth(monthEnd.getMonth() + 1)

    // Count members who joined by this month
    const totalMembers = members.filter((member) => new Date(member.joinDate) < monthEnd).length

    // Count new members in this specific month
    const newMembers = members.filter((member) => {
      const joinDate = new Date(member.joinDate)
      return (
        joinDate.getFullYear() === monthEnd.getFullYear() - (monthEnd.getMonth() === 0 ? 1 : 0) &&
        joinDate.getMonth() === (monthEnd.getMonth() === 0 ? 11 : monthEnd.getMonth() - 1)
      )
    }).length

    // Count active members
    const activeMembers = members.filter(
      (member) => new Date(member.joinDate) < monthEnd && member.status === "active",
    ).length

    monthlyData[monthKey] = {
      ...monthlyData[monthKey],
      totalMembers,
      newMembers,
      activeMembers,
    }
  })

  return Object.values(monthlyData)
}

export function calculateFinancialAnalytics(): FinancialAnalytics[] {
  const records = financialDb.getAll()
  const monthlyData: { [key: string]: FinancialAnalytics } = {}

  // Initialize last 12 months
  const now = new Date()
  for (let i = 11; i >= 0; i--) {
    const date = new Date(now.getFullYear(), now.getMonth() - i, 1)
    const monthKey = date.toISOString().slice(0, 7) // YYYY-MM format
    const monthName = date.toLocaleDateString("en-US", { month: "short", year: "numeric" })

    monthlyData[monthKey] = {
      month: monthName,
      tithes: 0,
      goodwill: 0,
      donations: 0,
      total: 0,
    }
  }

  // Aggregate financial data by month
  records.forEach((record) => {
    const recordDate = new Date(record.date)
    const monthKey = recordDate.toISOString().slice(0, 7)

    if (monthlyData[monthKey]) {
      monthlyData[monthKey][record.type] += record.amount
      monthlyData[monthKey].total += record.amount
    }
  })

  return Object.values(monthlyData)
}

export function calculateMemberContributions(): MemberContribution[] {
  const members = memberDb.getAll()
  const records = financialDb.getAll()

  const contributions = members.map((member) => {
    const memberRecords = records.filter((record) => record.memberId === member.id)
    const totalContributions = memberRecords.reduce((sum, record) => sum + record.amount, 0)
    const contributionCount = memberRecords.length
    const averageContribution = contributionCount > 0 ? totalContributions / contributionCount : 0
    const lastContribution =
      memberRecords.length > 0
        ? memberRecords.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0].date
        : ""

    return {
      memberId: member.id,
      memberName: `${member.firstName} ${member.lastName}`,
      totalContributions,
      contributionCount,
      averageContribution,
      lastContribution,
    }
  })

  return contributions
    .filter((contrib) => contrib.totalContributions > 0)
    .sort((a, b) => b.totalContributions - a.totalContributions)
}

export function calculateDashboardMetrics(): DashboardMetrics {
  const members = memberDb.getAll()
  const records = financialDb.getAll()
  const notes = birthdayDb.getAll()

  const totalMembers = members.length
  const activeMembers = members.filter((member) => member.status === "active").length
  const totalFinancialRecords = records.length
  const totalContributions = records.reduce((sum, record) => sum + record.amount, 0)

  // Calculate average monthly giving (last 12 months)
  const twelveMonthsAgo = new Date()
  twelveMonthsAgo.setMonth(twelveMonthsAgo.getMonth() - 12)
  const recentRecords = records.filter((record) => new Date(record.date) >= twelveMonthsAgo)
  const averageMonthlyGiving = recentRecords.reduce((sum, record) => sum + record.amount, 0) / 12

  // Birthday notes this year
  const currentYear = new Date().getFullYear()
  const birthdayNotesThisYear = notes.filter((note) => note.year === currentYear).length

  // Membership growth rate (last 6 months vs previous 6 months)
  const sixMonthsAgo = new Date()
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6)
  const recentMembers = members.filter((member) => new Date(member.joinDate) >= sixMonthsAgo).length
  const membershipGrowthRate = totalMembers > 0 ? (recentMembers / totalMembers) * 100 : 0

  const topContributors = calculateMemberContributions().slice(0, 5)

  return {
    totalMembers,
    activeMembers,
    totalFinancialRecords,
    totalContributions,
    averageMonthlyGiving,
    birthdayNotesThisYear,
    membershipGrowthRate,
    topContributors,
  }
}

export function getGivingTrends() {
  const records = financialDb.getAll()

  // Group by payment method
  const paymentMethods = records.reduce(
    (acc, record) => {
      acc[record.paymentMethod] = (acc[record.paymentMethod] || 0) + record.amount
      return acc
    },
    {} as Record<string, number>,
  )

  // Group by type
  const givingTypes = records.reduce(
    (acc, record) => {
      acc[record.type] = (acc[record.type] || 0) + record.amount
      return acc
    },
    {} as Record<string, number>,
  )

  return { paymentMethods, givingTypes }
}
