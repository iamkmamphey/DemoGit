// Authentication utilities for ICC Church Management System
export interface User {
  id: string
  username: string
  name: string
  role: "admin" | "staff" | "volunteer" | "financial"
  email: string
  createdAt: string
}

export interface AuthState {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
}

const STORAGE_KEY = "icc_auth_user"
const CREDENTIALS_STORAGE_KEY = "icc_user_credentials"

// Mock users for demonstration
const DEFAULT_USERS: User[] = [
  {
    id: "1",
    username: "admin",
    name: "Church Administrator",
    role: "admin",
    email: "admin@icc.church",
    createdAt: new Date().toISOString(),
  },
]

// Mock passwords (in a real app, these would be hashed)
const DEFAULT_CREDENTIALS: Record<string, string> = {
  admin: "admin123",
}

interface StoredCredential {
  username: string
  password: string
  userId: string
}

export class AuthService {
  static initializeDefaultAdmin(): void {
    const users = this.getAllUsers()
    const credentials = this.getAllCredentials()

    if (users.length === 0) {
      const defaultAdmin: User = {
        id: "1",
        username: "admin",
        name: "Church Administrator",
        role: "admin",
        email: "admin@icc.church",
        createdAt: new Date().toISOString(),
      }

      const defaultCredential: StoredCredential = {
        username: "admin",
        password: "admin123",
        userId: "1",
      }

      localStorage.setItem("icc_users", JSON.stringify([defaultAdmin]))
      localStorage.setItem(CREDENTIALS_STORAGE_KEY, JSON.stringify([defaultCredential]))
    }
  }

  static getAllUsers(): User[] {
    if (typeof window === "undefined") return []

    try {
      const stored = localStorage.getItem("icc_users")
      return stored ? JSON.parse(stored) : []
    } catch {
      return []
    }
  }

  static getAllCredentials(): StoredCredential[] {
    if (typeof window === "undefined") return []

    try {
      const stored = localStorage.getItem(CREDENTIALS_STORAGE_KEY)
      return stored ? JSON.parse(stored) : []
    } catch {
      return []
    }
  }

  static async login(username: string, password: string): Promise<User> {
    // Initialize default admin if needed
    this.initializeDefaultAdmin()

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const users = this.getAllUsers()
    const credentials = this.getAllCredentials()

    const user = users.find((u) => u.username === username)
    const credential = credentials.find((c) => c.username === username)

    if (!user || !credential || password !== credential.password) {
      throw new Error("Invalid username or password")
    }

    // Store user in localStorage
    localStorage.setItem(STORAGE_KEY, JSON.stringify(user))
    return user
  }

  static logout(): void {
    localStorage.removeItem(STORAGE_KEY)
  }

  static getCurrentUser(): User | null {
    if (typeof window === "undefined") return null

    try {
      const stored = localStorage.getItem(STORAGE_KEY)
      return stored ? JSON.parse(stored) : null
    } catch {
      return null
    }
  }

  static createUser(userData: Omit<User, "id" | "createdAt">, password: string): User {
    const users = this.getAllUsers()
    const credentials = this.getAllCredentials()

    // Check if username already exists
    if (users.some((u) => u.username === userData.username)) {
      throw new Error("Username already exists")
    }

    const newUser: User = {
      ...userData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    }

    const newCredential: StoredCredential = {
      username: userData.username,
      password,
      userId: newUser.id,
    }

    const updatedUsers = [...users, newUser]
    const updatedCredentials = [...credentials, newCredential]

    localStorage.setItem("icc_users", JSON.stringify(updatedUsers))
    localStorage.setItem(CREDENTIALS_STORAGE_KEY, JSON.stringify(updatedCredentials))

    return newUser
  }

  static updatePassword(userId: string, newPassword: string): void {
    const credentials = this.getAllCredentials()
    const users = this.getAllUsers()

    const user = users.find((u) => u.id === userId)
    if (!user) throw new Error("User not found")

    const updatedCredentials = credentials.map((c) => (c.userId === userId ? { ...c, password: newPassword } : c))

    localStorage.setItem(CREDENTIALS_STORAGE_KEY, JSON.stringify(updatedCredentials))
  }

  static deleteUser(userId: string): void {
    const users = this.getAllUsers()
    const credentials = this.getAllCredentials()

    // Don't allow deleting the last admin
    const remainingUsers = users.filter((u) => u.id !== userId)
    const hasAdmin = remainingUsers.some((u) => u.role === "admin")

    const userToDelete = users.find((u) => u.id === userId)
    if (userToDelete?.role === "admin" && !hasAdmin) {
      throw new Error("Cannot delete the last administrator")
    }

    const updatedUsers = users.filter((u) => u.id !== userId)
    const updatedCredentials = credentials.filter((c) => c.userId !== userId)

    localStorage.setItem("icc_users", JSON.stringify(updatedUsers))
    localStorage.setItem(CREDENTIALS_STORAGE_KEY, JSON.stringify(updatedCredentials))
  }

  static hasPermission(user: User | null, permission: string): boolean {
    if (!user) return false

    const permissions: Record<string, string[]> = {
      admin: ["read", "write", "delete", "manage_users", "view_analytics", "manage_financial", "delete_financial"],
      financial: ["read", "write", "view_analytics", "manage_financial", "delete_financial"],
      staff: ["read", "write", "view_analytics"],
      volunteer: ["read"],
    }

    return permissions[user.role]?.includes(permission) || false
  }

  static canAccessFinancials(user: User | null): boolean {
    return user?.role === "admin" || user?.role === "financial"
  }

  static canModifyFinancials(user: User | null): boolean {
    return this.hasPermission(user, "manage_financial")
  }

  static canDeleteFinancials(user: User | null): boolean {
    return this.hasPermission(user, "delete_financial")
  }

  static canManageMembers(user: User | null): boolean {
    return user?.role === "admin" || user?.role === "staff" || user?.role === "financial"
  }

  static canDeleteMembers(user: User | null): boolean {
    return this.hasPermission(user, "delete")
  }

  static canDelete(user: User | null): boolean {
    return this.hasPermission(user, "delete")
  }

  static canManageUsers(user: User | null): boolean {
    return this.hasPermission(user, "manage_users")
  }

  static canViewAnalytics(user: User | null): boolean {
    return this.hasPermission(user, "view_analytics")
  }

  static getRoleDisplayName(role: string): string {
    const roleNames: Record<string, string> = {
      admin: "Administrator",
      financial: "Financial Manager",
      staff: "Staff Member",
      volunteer: "Volunteer",
    }
    return roleNames[role] || role
  }
}
