// Mock database utilities using localStorage
import type { Member, FinancialRecord, BirthdayNote } from "./types"

const STORAGE_KEYS = {
  MEMBERS: "icc_members",
  FINANCIAL_RECORDS: "icc_financial_records",
  BIRTHDAY_NOTES: "icc_birthday_notes",
}

// Generic storage utilities
function getFromStorage<T>(key: string): T[] {
  if (typeof window === "undefined") return []
  try {
    const data = localStorage.getItem(key)
    return data ? JSON.parse(data) : []
  } catch {
    return []
  }
}

function saveToStorage<T>(key: string, data: T[]): void {
  if (typeof window === "undefined") return
  try {
    localStorage.setItem(key, JSON.stringify(data))
  } catch (error) {
    console.error("Failed to save to storage:", error)
  }
}

// Member management
export const memberDb = {
  getAll: (): Member[] => getFromStorage<Member>(STORAGE_KEYS.MEMBERS),

  getById: (id: string): Member | undefined => {
    const members = getFromStorage<Member>(STORAGE_KEYS.MEMBERS)
    return members.find((member) => member.id === id)
  },

  create: (member: Omit<Member, "id" | "createdAt" | "updatedAt">): Member => {
    const members = getFromStorage<Member>(STORAGE_KEYS.MEMBERS)
    const newMember: Member = {
      ...member,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    members.push(newMember)
    saveToStorage(STORAGE_KEYS.MEMBERS, members)
    return newMember
  },

  update: (id: string, updates: Partial<Member>): Member | null => {
    const members = getFromStorage<Member>(STORAGE_KEYS.MEMBERS)
    const index = members.findIndex((member) => member.id === id)
    if (index === -1) return null

    members[index] = {
      ...members[index],
      ...updates,
      updatedAt: new Date().toISOString(),
    }
    saveToStorage(STORAGE_KEYS.MEMBERS, members)
    return members[index]
  },

  delete: (id: string): boolean => {
    const members = getFromStorage<Member>(STORAGE_KEYS.MEMBERS)
    const filteredMembers = members.filter((member) => member.id !== id)
    if (filteredMembers.length === members.length) return false

    saveToStorage(STORAGE_KEYS.MEMBERS, filteredMembers)
    return true
  },
}

// Financial records management
export const financialDb = {
  getAll: (): FinancialRecord[] => getFromStorage<FinancialRecord>(STORAGE_KEYS.FINANCIAL_RECORDS),

  getByMemberId: (memberId: string): FinancialRecord[] => {
    const records = getFromStorage<FinancialRecord>(STORAGE_KEYS.FINANCIAL_RECORDS)
    return records.filter((record) => record.memberId === memberId)
  },

  create: (record: Omit<FinancialRecord, "id" | "createdAt">): FinancialRecord => {
    const records = getFromStorage<FinancialRecord>(STORAGE_KEYS.FINANCIAL_RECORDS)
    const newRecord: FinancialRecord = {
      ...record,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
    }
    records.push(newRecord)
    saveToStorage(STORAGE_KEYS.FINANCIAL_RECORDS, records)
    return newRecord
  },

  delete: (id: string): boolean => {
    const records = getFromStorage<FinancialRecord>(STORAGE_KEYS.FINANCIAL_RECORDS)
    const filteredRecords = records.filter((record) => record.id !== id)
    if (filteredRecords.length === records.length) return false

    saveToStorage(STORAGE_KEYS.FINANCIAL_RECORDS, filteredRecords)
    return true
  },
}

// Birthday notes management
export const birthdayDb = {
  getAll: (): BirthdayNote[] => getFromStorage<BirthdayNote>(STORAGE_KEYS.BIRTHDAY_NOTES),

  getByMemberId: (memberId: string): BirthdayNote[] => {
    const notes = getFromStorage<BirthdayNote>(STORAGE_KEYS.BIRTHDAY_NOTES)
    return notes.filter((note) => note.memberId === memberId)
  },

  create: (note: Omit<BirthdayNote, "id">): BirthdayNote => {
    const notes = getFromStorage<BirthdayNote>(STORAGE_KEYS.BIRTHDAY_NOTES)
    const newNote: BirthdayNote = {
      ...note,
      id: crypto.randomUUID(),
    }
    notes.push(newNote)
    saveToStorage(STORAGE_KEYS.BIRTHDAY_NOTES, notes)
    return newNote
  },
}

// Initialize with sample data if empty
export function initializeSampleData() {
  const members = memberDb.getAll()
  if (members.length === 0) {
    // Create sample members
    memberDb.create({
      firstName: "John",
      lastName: "Smith",
      dateOfBirth: "1985-03-15",
      address: {
        street: "123 Faith Street",
        city: "Springfield",
        state: "IL",
        zipCode: "62701",
      },
      email: "john.smith@email.com",
      phone: "(555) 123-4567",
      joinDate: "2020-01-15",
      status: "active",
    })

    memberDb.create({
      firstName: "Sarah",
      lastName: "Johnson",
      dateOfBirth: "1990-07-22",
      address: {
        street: "456 Hope Avenue",
        city: "Springfield",
        state: "IL",
        zipCode: "62702",
      },
      email: "sarah.johnson@email.com",
      phone: "(555) 987-6543",
      joinDate: "2021-06-10",
      status: "active",
    })
  }
}
