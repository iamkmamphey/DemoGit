// Database schema types for ICC Church Management System

export interface Member {
  id: string
  firstName: string
  lastName: string
  dateOfBirth: string
  address: {
    street: string
    city: string
    state: string
    zipCode: string
  }
  email: string
  phone?: string
  joinDate: string
  status: "active" | "inactive" | "visitor"
  notes?: string
  spouse?: string
  children?: string
  formerChurch?: string
  nextOfKin?: {
    name: string
    relationship: string
    phone: string
    email?: string
  }
  createdAt: string
  updatedAt: string
}

export interface FinancialRecord {
  id: string
  memberId: string
  type: "tithe" | "goodwill" | "donation"
  amount: number
  date: string
  description?: string
  paymentMethod: "cash" | "check" | "card" | "online"
  createdAt: string
}

export interface BirthdayNote {
  id: string
  memberId: string
  year: number
  message: string
  sentDate: string
  createdBy: string
}

export interface MembershipGrowth {
  date: string
  totalMembers: number
  newMembers: number
  inactiveMembers: number
}

export interface FinancialSummary {
  period: string
  totalTithes: number
  totalGoodwill: number
  totalDonations: number
  memberCount: number
  averagePerMember: number
}
